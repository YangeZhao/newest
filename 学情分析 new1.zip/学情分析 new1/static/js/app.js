const app = Vue.createApp({
    components: {
        'login-component': LoginComponent,
        'main-component': MainComponent
    },
    template: `
        <login-component v-if="!isLoggedIn" @login-success="handleLoginSuccess"></login-component>
        <main-component v-else></main-component>
    `,
    setup() {
        const isLoggedIn = Vue.ref(false);

        const handleLoginSuccess = () => {
            isLoggedIn.value = true;
        };

        return {
            isLoggedIn,
            handleLoginSuccess
        };
    }
});

// 使用Element Plus
app.use(ElementPlus);

// 挂载应用
app.mount('#app');
