const { createApp, ref, reactive,onMounted,computed,watch,nextTick,toRefs } = Vue;
const { ElMessage,ElMessageBox,ElLoading,ElButton, ElRadioGroup, ElRadioButton, ElCheckbox, ElIcon } = ElementPlus;
const handleSelect = (index) => {//页面跳转
    switch(index) {
        case '1-1':
            window.location.href = '/pages/create-course.html';
            break;
        case '1-2':
            window.location.href = '/pages/add-parallel-class.html';
            break;
        case '1-3':
            window.location.href = '/pages/student-management.html';
            break;
        case '2-1':
            window.location.href = '/pages/homework-upload.html';
            break;
        case '2-2':
            window.location.href = '/pages/homework-edit.html';
            break;
        case '2-3':
            window.location.href = '/pages/homework-exam.html';
            break;
        case '3':
            window.location.href = '/index.html#3';
            break;
        case '4':
            window.location.href = '/pages/teacher-analysis.html';
            break;
        case '5':
            window.location.href = '/pages/user-management.html';
            break;
        case '6':
            window.location.href = '/pages/create-colleges.html';
            break;
        default:
            window.location.href = '/index.html';
    }
};

const isLogin = () => {//检查登录状态
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    console.log("登录",isLoggedIn);
    if (!isLoggedIn) {
        window.location.href = '/login.html';
        return;
    }
};
const logout = () => {//退出登录
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('username');
    localStorage.removeItem('id');
    localStorage.removeItem('type');
    window.location.href = '/login.html';
};

const userInfo = ref({//用户信息
    name: localStorage.getItem('username'),
    id:localStorage.getItem('id'),
    type:localStorage.getItem('type')
});
